import os
import torch
from torch.utils.data import DataLoader
import pytorch_lightning as pl
from pytorch_lightning.callbacks import LearningRateMonitor
from pytorch_lightning import seed_everything
import hydra
from omegaconf import DictConfig

from src.models.models import MODELS
from src.models.models import get_model
from src.datasets import datasets
import src.utils.hydra_utils as hydra_utils
from src.utils.common import override_weights
'''
导入必要的库和模块，如 os、torch、pytorch_lightning、hydra 等。
使用 Hydra 框架进行配置，配置文件路径为 "../configs/"，配置文件名为 "config.yaml"。
设置随机种子（如果在配置中指定了种子）。
初始化数据集，加载测试数据集并创建 DataLoader。
初始化模型，使用配置中指定的模型名称和检查点路径。
使用 PyTorch Lightning 的 Trainer 类进行模型测试。
整体而言，这个程序文件的主要目的是加载配置、初始化数据集和模型，然后进行模型测试。
'''

log = hydra_utils.get_logger(__name__)


@hydra.main(config_path="../configs/", config_name="config.yaml")
def main(config: DictConfig):

    if "seed" in config.trainer:
        seed_everything(config.trainer.seed)

    hydra_utils.extras(config)
    hydra_utils.print_config(config, resolve=True)

    # setup dataset
    log.info("initializing dataset")
    test_dataset = datasets.get_dataset(config, "test")
    test_loader = DataLoader(
        test_dataset,
        batch_size=config.dataset.eval_batch_size,
        shuffle=False,
        num_workers=config.dataset.num_workers,
        collate_fn=test_dataset.collate_fn if hasattr(test_dataset, "collate_fn") else None
    )

    # setup model
    log.info("initializing model")
    model = MODELS[config.model.name].load_from_checkpoint(
        config.trainer.checkpoint,
        **{
            "cfg": config
        }
    )

    # start training
    trainer = pl.Trainer(
        gpus=config.trainer.gpus,
    )
    trainer.test(model, test_dataloaders=test_loader)


if __name__ == "__main__":
    main()
