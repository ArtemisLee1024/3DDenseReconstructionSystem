from weakref import KeyedRef
import hydra
import numpy as np
import os    
from omegaconf import DictConfig
import torch
import time
from torch.utils.data import DataLoader
from tqdm import tqdm
from pytorch_lightning import seed_everything

from src.datasets import datasets
from src.datasets.fusion_inference_dataset import IterableInferenceDataset
import src.utils.o3d_helper as o3d_helper
import src.utils.hydra_utils as hydra_utils
import src.utils.voxel_utils as voxel_utils
from src.models.fusion.local_point_fusion import LitFusionPointNet
from src.models.sparse_volume import SparseVolume
from src.utils.render_utils import calculate_loss
from src.utils.common import to_cuda, Timer
import third_parties.fusion as fusion

'''
这段代码是一个用于进行RGB-D图像的体积三维稠密重建的程序。
代码中使用了PyTorch和PyTorch Lightning进行深度学习模型的实现和训练。
采用了多线程加载数据集和数据处理。
利用弱引用（weakref）实现了一个缓存中间件 Cacher，用于管理数据对象的引用计数
'''
log = hydra_utils.get_logger(__name__)


class NeuralMap:

    def __init__(
        self,
        dimensions,
        config,
        pointnet,
        working_dir,
    ):
        '''
        初始化函数 __init__：
        该函数初始化了一个名为 NeuralMap 的类，接受多个参数，包括维度 dimensions、
        配置信息 config、PointNet模型 pointnet 和工作目录 working_dir。
        在初始化过程中，提取了配置中的一些参数，设置了体素边界、体素大小等。
        创建了一个名为 SparseVolume 的类实例作为体素容器，并初始化了一些属性，如体素大小、体素边界等。
        初始化了一个名为 TSDFVolume 的类实例，用于TSDF（Truncated Signed Distance Function）体积的集成。
        '''
        if "/" in config.dataset.scan_id:
            self.dataset_name, self.scan_id = config.dataset.scan_id.split("/")
        else:
            self.scan_id = config.dataset.scan_id
        min_coords, max_coords, n_xyz = voxel_utils.get_world_range(
            dimensions, config.model.voxel_size)
        self.pointnet = pointnet
        self.working_dir = working_dir
        self.config = config
        self.volume = SparseVolume(
            config.model.feature_vector_size,
            config.model.voxel_size,
            dimensions,
            config.model.min_pts_in_grid)
        self.bound_min = torch.from_numpy(min_coords).to("cuda").float()
        self.bound_max = torch.from_numpy(max_coords).to("cuda").float()
        self.voxel_size = config.model.voxel_size
        self.n_xyz = n_xyz
        self.dimensions = dimensions
        self.sampling_size = config.dataset.num_pixels
        self.train_ray_splits = config.model.train_ray_splits
        self.ray_max_dist = config.model.ray_tracer.ray_max_dist
        self.truncated_units = config.model.ray_tracer.truncated_units
        self.truncated_dist = min(self.truncated_units * self.voxel_size * 0.5, 0.1)
        self.depth_scale = 1000.
        self.sdf_delta = None
        self.skip_images = config.dataset.skip_images
        self.tsdf_voxel_size = 0.025
        self.sdf_delta_weight = config.model.sdf_delta_weight
        min_coords, max_coords, n_xyz = voxel_utils.get_world_range(
            dimensions, self.tsdf_voxel_size)
        vol_bnds = np.zeros((3,2))
        vol_bnds[:, 0] = min_coords
        vol_bnds[:, 1] = max_coords
        self.tsdf_vol = fusion.TSDFVolume(
            vol_bnds,
            voxel_size=self.tsdf_voxel_size)
        
        self.frames = []
        self.iterable_dataset = IterableInferenceDataset(
            self.frames, self.ray_max_dist, self.bound_min.cpu(),
            self.bound_max.cpu(), self.n_xyz, self.sampling_size, config.dataset.confidence_level)

    def integrate(self, frame):
        '''
        体素集成函数 integrate：
        该函数用于将RGB-D帧集成到SparseVolume和TSDFVolume中。
        利用PointNet模型对点云进行编码，获取特征、权重等信息，然后在SparseVolume中进行集成。
        同时，在TSDFVolume中也进行了集成，利用RGB和深度信息。
        '''
        if len(frame['input_pts']) == 0:
            return None
        with torch.no_grad():
            # local-level fusion
            fine_feats, fine_weights, _, fine_coords, fine_n_pts = self.pointnet.encode_pointcloud(
                frame['input_pts'],  # [1, N, 6]
                self.volume.n_xyz,
                self.volume.min_coords,
                self.volume.max_coords,
                self.volume.voxel_size,
                return_dense=self.pointnet.dense_volume
            )
            if fine_feats is None:
                return None
            self.volume.track_n_pts(fine_n_pts)
            self.pointnet._integrate(
                self.volume,
                fine_coords,
                fine_feats,
                fine_weights)
            # tsdf fusion
            rgbd = frame['rgbd'].cpu().numpy()
            depth_map = rgbd[0, -1, :, :]
            rgb = (rgbd[0, :3, :, :].transpose(1, 2, 0) + 0.5) * 255.
            # depth_map = rgbd[0, 3, :, :]
            self.tsdf_vol.integrate(
                rgb,  # [h, w, 3], [0, 255]
                depth_map,  # [h, w], metric depth
                frame['intr_mat'].cpu().numpy()[0],
                frame["T_wc"].cpu().numpy()[0],
                obs_weight=1.)

    def optimize(self, n_iters, last_frame):
        '''
        优化函数 optimize：
        该函数用于优化SparseVolume的特征，通过对数据集进行迭代训练。
        利用Adam优化器，按照指定的训练间隔和步数进行体素特征的优化。
        '''
        self.volume.to_tensor()
        tsdf_delta = self.prepare_tsdf_volume()
        self.volume.features = torch.nn.Parameter(self.volume.features)
        self.iterable_dataset.n_iters = n_iters
        self.iterable_dataset.last_frame = last_frame
        loader = torch.utils.data.DataLoader(self.iterable_dataset, batch_size=None, num_workers=4)
        optimizer = torch.optim.Adam([self.volume.features], lr=0.001)
        for rays in tqdm(loader):
            optimizer.zero_grad()
            if torch.isnan(rays['T_wc']).any():
                continue
            to_cuda(rays)
            batch_loss = {}
            n_rays = rays['uv'].shape[1]
            n_splits = n_rays / self.train_ray_splits
            for i, indx in enumerate(torch.split(
                torch.arange(n_rays).cuda(), self.train_ray_splits, dim=0
            )):
                ray_splits = {
                    "uv": torch.index_select(rays['uv'], 1, indx),
                    "rgb": torch.index_select(rays['rgb'], 1, indx),
                    "gt_pts": torch.index_select(rays['gt_pts'], 1, indx),
                    "mask": torch.index_select(rays['mask'], 1, indx),
                    "neighbor_pts": torch.index_select(rays['neighbor_pts'], 1, indx),
                    "neighbor_masks": torch.index_select(rays['neighbor_masks'], 1, indx),
                    "T_wc": rays['T_wc'],
                    "intr_mat": rays['intr_mat']}
                split_loss_out = calculate_loss(
                    self.volume,
                    ray_splits,
                    self.pointnet.nerf,
                    truncated_units=self.truncated_units,
                    truncated_dist=self.truncated_dist,
                    ray_max_dist=self.ray_max_dist,
                    sdf_delta=tsdf_delta)
                loss_for_backward = 0
                for k in split_loss_out:
                    if k[0] != "_":
                        loss_for_backward += split_loss_out[k]
                        if k not in batch_loss:
                            batch_loss[k] = split_loss_out[k]
                        else:
                            batch_loss[k] += split_loss_out[k]
                loss_for_backward.backward()
            optimizer.step()
        # store optimized features back to the sparse_volume        
        self.volume.insert(
            self.volume.active_coordinates,
            self.volume.features,
            self.volume.weights,
            self.volume.num_hits)

    def extract_mesh(self):
        '''
        提取三角网格函数 extract_mesh：
        该函数用于从SparseVolume和TSDFVolume中提取三角网格，利用Marching Cubes算法生成网格。
        '''
        sdf_delta = self.prepare_tsdf_volume()
        surface_pts, mesh = self.volume.meshlize(self.pointnet.nerf, sdf_delta)
        return mesh

    def prepare_tsdf_volume(self):
        '''
        准备TSDF体素函数 prepare_tsdf_volume：
        该函数用于准备TSDF体素，包括获取TSDF体素数据、缩放等操作
        '''
        tsdf_volume, _ = self.tsdf_vol.get_volume()
        tsdf_volume = tsdf_volume * (self.tsdf_voxel_size * 5)
        tsdf_volume = torch.from_numpy(tsdf_volume).to(self.pointnet.device).float().unsqueeze(0).unsqueeze(0)
        resized_tsdf_volume = tsdf_volume
        # resized_tsdf_volume = F.interpolate(
        #     tsdf_volume,
        #     size=(
        #         self.n_xyz[0],
        #         self.n_xyz[1],
        #         self.n_xyz[2]
        #     ),
        #     mode="trilinear",
        #     align_corners=True)
        resized_tsdf_volume = torch.clip(
            resized_tsdf_volume, min=-self.truncated_dist, max=self.truncated_dist)
        resized_tsdf_volume *= self.sdf_delta_weight
        return resized_tsdf_volume

    def save(self):
        '''
        保存函数 save：
        该函数用于保存TSDF体素和SparseVolume的最终结果。
        '''
        # save tsdf volume
        tsdf_out_path = os.path.join(self.working_dir, self.scan_id + ".npy")
        tsdf_vol, _ = self.tsdf_vol.get_volume()
        tsdf_vol = tsdf_vol * (self.tsdf_voxel_size * 5)
        np.save(tsdf_out_path, tsdf_vol)
        self.volume.save(os.path.join(self.working_dir, "final"))
        
def track_memory():
    div_GB = 1024 * 1024 * 1024
    print("GPU status:")
    print(f"allocated: {torch.cuda.memory_allocated() / div_GB} GB")
    print(f"max allocated: {torch.cuda.max_memory_allocated() / div_GB} GB")
    print(f"reserved: {torch.cuda.memory_reserved() / div_GB} GB")
    print(f"max reserved: {torch.cuda.max_memory_reserved() / div_GB} GB")


@hydra.main(config_path="../configs/", config_name="config.yaml")
def main(config: DictConfig):
    '''
    主程序 - main 函数：
    初始化配置和模型：
    使用Hydra库加载配置文件，设置随机种子等。
    初始化数据集和数据加载器。

    循环处理每一帧：
    利用NeuralMap类处理数据集中的每一帧，进行局部和全局融合。

    性能统计和结果保存：
    统计局部和全局融合的速度。
    最终保存优化后的三角网格和TSDF体素。
    '''
    if "seed" in config.trainer:
        seed_everything(config.trainer.seed)

    hydra_utils.extras(config)
    hydra_utils.print_config(config, resolve=True)

    # setup dataset
    log.info("initializing dataset")
    val_dataset = datasets.get_dataset(config, "val")
    val_loader = DataLoader(
        val_dataset,
        batch_size=config.dataset.eval_batch_size,
        shuffle=False,
        num_workers=config.dataset.num_workers,
        collate_fn=val_dataset.collate_fn if hasattr(val_dataset, "collate_fn") else None
    )

    plots_dir = os.path.join(os.getcwd(), config.dataset.scan_id)
    if not os.path.exists(plots_dir):
        os.makedirs(plots_dir)

    # setup model
    log.info("initializing model")
    pointnet_model = LitFusionPointNet(config)
    pretrained_weights = torch.load(config.trainer.checkpoint)
    pointnet_model.load_state_dict(pretrained_weights['state_dict'])
    pointnet_model.eval()
    pointnet_model.cuda()
    pointnet_model.freeze()
    neural_map = NeuralMap(
        val_dataset.dimensions,
        config,
        pointnet_model,
        working_dir=plots_dir)
    timer = Timer(["local", "global"])
    for idx, data in enumerate(tqdm(val_loader)):
        # LOCAL FUSION:
        # integrate information from the new frame to the feature volume
        frame, _ = data
        for k in frame.keys():
            if isinstance(frame[k], torch.Tensor):
                frame[k] = frame[k].cuda().float()
        timer.start("local")
        neural_map.integrate(frame)
        timer.log("local")
        if torch.isnan(frame['T_wc']).any():
            continue
        meta_frame = {
            "frame_id": frame["frame_id"],
            "scan_id": frame["scene_id"],
            "T_wc": frame["T_wc"].clone().cpu(),
            "intr_mat": frame["intr_mat"].clone().cpu(),
            "img_path": frame['img_path'][0],
            "depth_path": frame['depth_path'][0],
        }
        if "mask_path" in frame:
            meta_frame['mask_path'] = frame['mask_path'][0]
        del frame
        neural_map.frames.append(meta_frame)
        # clear memory for open3d hashmap
        if (idx+1) % 2 == 0:
            torch.cuda.empty_cache()
        if config.model.mode == "demo":
            if (idx) % config.model.optim_interval == 0:
                last_frame = max(0, len(neural_map.frames) - config.model.optim_interval)
                n_iters = min(len(neural_map.frames), config.model.optim_interval) * neural_map.skip_images
                timer.start("global")
                neural_map.optimize(n_iters=n_iters, last_frame=last_frame)
                timer.log("global")
                mesh = neural_map.extract_mesh()
                mesh = o3d_helper.post_process_mesh(mesh)
                mesh_out_path = os.path.join(neural_map.working_dir, f"{idx}.ply")
                mesh.export(mesh_out_path)
    neural_map.volume.to_tensor()
    mesh = neural_map.extract_mesh()
    mesh.export(os.path.join(neural_map.working_dir, "before_optim.ply"))
    global_steps = int(len(neural_map.frames) * neural_map.skip_images)
    global_steps = global_steps * 2 if config.model.mode != "demo" else global_steps
    timer.start("global")
    neural_map.optimize(n_iters=global_steps, last_frame=-1)
    timer.log("global")
    for n in ["local", "global"]:
        print(f"speed on {n} fusion: {global_steps / timer.times[n]} fps")
    
    mesh = neural_map.extract_mesh()
    mesh = o3d_helper.post_process_mesh(mesh, vertex_threshold=neural_map.voxel_size / 4)
    mesh_out_path = os.path.join(neural_map.working_dir, "final.ply")
    mesh.export(mesh_out_path)
    neural_map.save()


if __name__ == "__main__":
    main()