import os
import torch
from torch.utils.data import DataLoader
import pytorch_lightning as pl
from pytorch_lightning.callbacks import LearningRateMonitor
from pytorch_lightning import seed_everything
import hydra
from omegaconf import DictConfig


from src.models.models import get_model
from src.datasets import datasets
import src.utils.hydra_utils as hydra_utils
from src.utils.common import override_weights

'''
该程序实现了一个基于PyTorch Lightning的深度学习模型训练框架，通过Hydra进行配置管理，简化了模型训练的流程。
代码中使用了Hydra库进行配置管理，可以通过配置文件轻松调整模型和训练参数。
使用了PyTorch Lightning库简化了深度学习模型的训练过程，提供了一些方便的功能，如模型保存、学习率监控等。
对训练过程进行了一些配置，如使用的GPU数量、训练轮数、是否打乱数据等。
'''

log = hydra_utils.get_logger(__name__)


@hydra.main(config_path="../configs/", config_name="config.yaml")
def main(config: DictConfig):
    '''
    main 函数：

    初始化配置和模型：
    使用Hydra库加载配置文件，设置随机种子等。
    初始化了一个名为 model 的深度学习模型，使用了get_model函数，根据配置动态调整模型参数，包括数据集的样本数和维度。

    数据集初始化：
    初始化训练集和验证集的DataLoader，用于加载训练和验证数据。
    数据加载过程中设置了一些参数，如批量大小、是否打乱数据等。

    模型训练配置：
    设置了模型训练的一些参数，包括使用的GPU数量、最大训练轮数、回调函数等。
    配置了模型保存的回调函数 ModelCheckpoint，用于保存模型的最佳权重和最后一轮的权重。
    如果配置中设置了 weight_only，则加载预训练权重。

    开始训练：
    创建了一个 Trainer 实例，用于管理模型的训练过程。
    调用 fit 函数开始训练，传入模型、训练集和验证集的 DataLoader。
    '''
    if "seed" in config.trainer:
        seed_everything(config.trainer.seed)

    hydra_utils.extras(config)
    hydra_utils.print_config(config, resolve=True)


    # setup dataset
    log.info("initializing dataset")
    train_dataset = datasets.get_dataset(config, "train")
    train_loader = DataLoader(
        train_dataset,
        batch_size=config.dataset.train_batch_size,
        shuffle=config.dataset.shuffle,
        num_workers=config.dataset.num_workers,
        collate_fn=train_dataset.collate_fn if hasattr(train_dataset, "collate_fn") else None
    )
    val_dataset = datasets.get_dataset(config, "val")
    val_loader = DataLoader(
        val_dataset,
        batch_size=config.dataset.eval_batch_size,
        shuffle=False,
        num_workers=config.dataset.num_workers,
        collate_fn=val_dataset.collate_fn if hasattr(val_dataset, "collate_fn") else None
    )

    # setup model
    log.info("initializing model")
    model_dynamic_cfg = {
        "num_samples": len(train_dataset),
    }
    if hasattr(train_dataset, "dimensions"):
        model_dynamic_cfg = {
            "dimensions": train_dataset.dimensions
        }
    model = get_model(config, **model_dynamic_cfg)

    log.info("setup checkpoint callback")
    # setup checkpoint callback
    checkpoint_callback = pl.callbacks.ModelCheckpoint(
        dirpath=None,  # the path is set by hydra in config.yaml TODO: add flexibility?
        monitor="val_loss",  # TODO: add monitor
        save_top_k=50,
        period=1,
        save_last=True
    )
    lr_monitor = LearningRateMonitor(logging_interval='step')

    if config.trainer.weight_only:
        checkpoint = None
    else:
        checkpoint = config.trainer.checkpoint

    # start training
    trainer = pl.Trainer(
        gpus=config.trainer.gpus,
        max_epochs=config.trainer.max_epochs,
        callbacks=[checkpoint_callback, lr_monitor],
        log_every_n_steps=5,
        resume_from_checkpoint=checkpoint,
        check_val_every_n_epoch=config.trainer.check_val_every_n_epoch,
        precision=16,
    )
    # load pretrained data
    if (config.trainer.checkpoint is not None) and config.trainer.weight_only:
        pretrained_weights = torch.load(
            config.trainer.checkpoint
        )['state_dict']
        override_weights(
            model, pretrained_weights, keys=['decoder']
        )
    trainer.fit(model, train_loader, val_loader)


if __name__ == "__main__":
    main()
